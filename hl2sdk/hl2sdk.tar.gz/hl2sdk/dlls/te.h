//========= Copyright � 1996-2005, Valve Corporation, All rights reserved. ============//
//
// Purpose: 
//
// $Workfile:     $
// $NoKeywords: $
//=============================================================================//

#if !defined( TE_H )
#define TE_H
#ifdef _WIN32
#pragma once
#endif

#include "itempents.h"

#endif // TE_H